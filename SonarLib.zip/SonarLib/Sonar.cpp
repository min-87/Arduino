#include "Sonar.h"

Sonar::Sonar(int echo, int trig) {
  echoPin = echo;
  trigPin = trig;
}
Sonar::Sonar(int echo, int trig, int bod) {
  echoPin = echo;
  trigPin = trig;
  spd = bod;
}

void Sonar::begin() {
  Serial.begin(spd);
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
}

int Sonar::distance() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  dur = pulseIn(echoPin, HIGH);
  dist = dur / 58.2;
  if (dist >= maxRange || dist <= minRange)
  {
    return 0;
  }
  else
  {
    return dist;
  }
}

void Sonar::readDistance() {
  Serial.println(distance());
}
