#ifndef SONAR_H
#define SONAR_H
#include <Arduino.h>
class Sonar {
  public:
    Sonar(int echo, int trig);
    Sonar(int echo, int trig, int bod);
    void begin();
    int distance();
    void readDistance();
  private:
    int echoPin;
    int trigPin;
    int spd;
    long dur, dist;
    int maxRange = 300;
    int minRange = 0;
};

#endif
